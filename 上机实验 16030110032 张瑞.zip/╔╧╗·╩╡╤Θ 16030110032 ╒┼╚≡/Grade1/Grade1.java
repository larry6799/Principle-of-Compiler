import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.io.UnsupportedEncodingException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Grade1 { 

    //mapper
    public static class Grade1Mapper extends Mapper<Object,Text,Text,IntWritable>{

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            String banji = value.toString().split(",")[0];
            String xingming = value.toString().split(",")[1];
			String kechen = value.toString().split(",")[2];
			String shuxing = value.toString().split(",")[3];
			String fenshu = value.toString().split(",")[4];
			
			if("����".equals(shuxing)){
				int Grade1=Integer.parseInt(fenshu);
				context.write(new Text(xingming), new IntWritable(Grade1));
			}		
            
        }
    }

    //reducer
    public static class Grade1Reducer extends Reducer<Text,IntWritable,Text,IntWritable>{
		
		private IntWritable result = new IntWritable();
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {

              int sum = 0,cnt=0;
			  for (IntWritable val : values) {
				sum += val.get();
				cnt++;
			  }
			  
			  result.set(sum/cnt);
			context.write(key, result);
        }
    }


    public static void main(String [] args) throws IOException, ClassNotFoundException, InterruptedException {

        Configuration conf=new Configuration();

        Job job= Job.getInstance(conf);

        job.setJarByClass(Grade1.class);

        job.setMapperClass(Grade1Mapper.class);
        job.setReducerClass(Grade1Reducer.class);

        //job.setMapOutputValueClass(Text.class);
        //job.setMapOutputKeyClass(IntWritable.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        FileInputFormat.setInputPaths(job,new Path(args[0]));
        FileOutputFormat.setOutputPath(job,new Path(args[1]));

        boolean res = job.waitForCompletion(true);
        System.exit(res?0:1);
    }
}
 