import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Yesun { 

    //mapper
    public static class YesunMapper extends Mapper<Object,Text,Text,Text>{

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            String son = value.toString().split(",")[0];
            String father = value.toString().split(",")[1];
			
            context.write(new Text(father),new Text("-"+son));
            context.write(new Text(son),new Text("+"+father));
        }
    }

    //reducer
    public static class YesunReducer extends Reducer<Text,Text,Text,Text>{

        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

            ArrayList<Text> father=new ArrayList<Text>();
            ArrayList<Text> son=new ArrayList<Text>();

            for (Text t:values){
                String str = t.toString();

                if(str.startsWith("-")){
                    son.add(new Text(str.substring(1)));
                }else{
                    father.add(new Text(str.substring(1)));
                }
            }

            for (int i=0;i<son.size();i++){
                for (int j=0;j<father.size();j++){
                    context.write(new Text(son.get(i)),new Text(father.get(j)));
                }
            }
        }
    }


    public static void main(String [] args) throws IOException, ClassNotFoundException, InterruptedException {

        Configuration conf=new Configuration();
		/*String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		if (otherArgs.length < 2) {
		  System.err.println("Usage: wordcount <in> [<in>...] <out>");
		  System.exit(2);
		}*/
        Job job= Job.getInstance(conf);

        job.setJarByClass(Yesun.class);

        job.setMapperClass(YesunMapper.class);
        job.setReducerClass(YesunReducer.class);

        job.setMapOutputValueClass(Text.class);
        job.setMapOutputKeyClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.setInputPaths(job,new Path(args[0]));
        FileOutputFormat.setOutputPath(job,new Path(args[1]));

        boolean res = job.waitForCompletion(true);
        System.exit(res?0:1);
    }
}
 