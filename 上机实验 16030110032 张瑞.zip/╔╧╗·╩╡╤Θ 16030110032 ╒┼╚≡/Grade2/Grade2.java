import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Grade2 { 

    //mapper
    public static class Grade2Mapper extends Mapper<Object,Text,Text,IntWritable>{

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            String banji = value.toString().split(",")[0];
            String xingming = value.toString().split(",")[1];
			String kechen = value.toString().split(",")[2];
			String shuxing = value.toString().split(",")[3];
			String fenshu = value.toString().split(",")[4];
			int grade2=Integer.parseInt(fenshu);

			context.write(new Text(kechen+"-"+banji), new IntWritable(grade2));		
            
        }
    }

    //reducer
    public static class Grade2Reducer extends Reducer<Text,IntWritable,Text,IntWritable>{
		
		private IntWritable result = new IntWritable();
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {

              int sum = 0,tot=0;
			  for (IntWritable val : values) {
				sum += val.get();
				tot++;
			  }
			  
			  result.set(sum/tot);
			context.write(key, result);
        }
    }


    public static void main(String [] args) throws IOException, ClassNotFoundException, InterruptedException {

        Configuration conf=new Configuration();
		/*String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		if (otherArgs.length < 2) {
		  System.err.println("Usage: wordcount <in> [<in>...] <out>");
		  System.exit(2);
		}*/
        Job job= Job.getInstance(conf);

        job.setJarByClass(Grade2.class);

        job.setMapperClass(Grade2Mapper.class);
        job.setReducerClass(Grade2Reducer.class);

        //job.setMapOutputValueClass(Text.class);
        //job.setMapOutputKeyClass(IntWritable.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        FileInputFormat.setInputPaths(job,new Path(args[0]));
        FileOutputFormat.setOutputPath(job,new Path(args[1]));

        boolean res = job.waitForCompletion(true);
        System.exit(res?0:1);
    }
}
 